# rs_drift Package

This is a simple package to calculate the drift of radiosondes.
